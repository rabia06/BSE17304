﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            driver.Url = "http://localhost:8080/grads.html";
            driver.Manage().Window.Maximize();

            driver.FindElement(By.Id("textLabGrade")).SendKeys("60");
            driver.FindElement(By.Id("textCourseGrade")).SendKeys("40");
            IWebElement element = driver.FindElement(By.LinkText("btnCalculate"));
            element.Click();

        }


        [Test]
        public void TestCas1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Url = "http://localhost:8080/grads.html";
            driver.Manage().Window.Maximize();

            driver.FindElement(By.Id("textLabGrade")).SendKeys("60");
            driver.FindElement(By.Id("textCourseGrade")).SendKeys("40");
            IWebElement element = driver.FindElement(By.LinkText("btnCalculate"));
            element.Click();

        }

        [Test, Combinatorial]
        public void Test2([Values(40, 50, 60, 70, 80, 90)] int grade, [Values(50,70,20,10,40,60)] int gradess)
        {
            IWebDriver driver = new ChromeDriver();
            driver.Url = "http://localhost:8080/grads.html";
            driver.Manage().Window.Maximize();

            driver.FindElement(By.Id("textLabGrade")).Click();
            driver.FindElement(By.Id("textCourseGrade")).Click(); ;
            IWebElement element = driver.FindElement(By.LinkText("btnCalculate"));
            element.Click();
        }
       
    }
}
